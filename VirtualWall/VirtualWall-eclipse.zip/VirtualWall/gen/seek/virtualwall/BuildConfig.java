/** Automatically generated file. DO NOT MODIFY */
package seek.virtualwall;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}